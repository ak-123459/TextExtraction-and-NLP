# --------------------------------------------   Data Analysis ----------------------------------------------

# Importing necessary libraries
import os  # For operating system dependent functionality
import re  # For regular expression operations
import spacy  # For NLP tasks
import numpy as np  # For numerical operations
from collections import Counter  # To count hashable objects
from wordcloud import WordCloud  # To generate word clouds
import matplotlib.pyplot as plt  # For plotting data
import plotly.express as px  # For interactive plots
import seaborn as sb  # For data visualization based on matplotlib
from textblob import TextBlob  # For text processing and NLP

# Get the directory where the current file is located
current_directory = os.path.abspath(os.path.dirname(__file__))

# Loading the SpaCy model for English language
model = spacy.load('en_core_web_sm')

# Preparing data structures for analysis
Topic_withSent = {}  # Dictionary to store topics with their sentiment scores
Common_topic = []  # List to store the most frequent topics
Most_frq_word = []  # List to store the most frequent words
Most_frq_entity = []  # List to store the most frequent named entities
index = 0  # Index to track the current article being processed

# Function to analyze sentiment of sentences containing a specific word
def SentimentCommonTopic(word, article_sent: list):
    POS_ = []
    NEG_ = []
    for sent in article_sent:
        sent = str(sent).lower()
        if word.lower() in sent.strip().split():
            polarity = TextBlob(sent).polarity
            if polarity > 0:
                POS_.append(polarity)
            if polarity < 0:
                NEG_.append(polarity)
    return [sum(POS_), sum(NEG_) * -1]

# Function to clean and preprocess text
def Preprocess_text(text):
    Cleaned = []
    for token in model(text):
        if not (token.is_stop or token.is_punct or token.is_space):
            Cleaned.append(token.text.lower())
    return Cleaned

# Setting the path to articles
path_article = os.path.join(current_directory, "Extracted_articles")


# Process each article in the directory
for file_name in os.listdir(path_article):
    with open(os.path.join(path_article, file_name), 'r', encoding='utf-8') as file:
        Article = file.read()

    # Extract the content of the article
    indices_object = re.finditer(pattern='Article:', string=Article)
    endIn = [i.end() for i in indices_object][0]
    article = Article[endIn:].strip()
    doc = model(article)

    # Preprocess the text and calculate word frequency
    preprocess_text = Preprocess_text(article)
    word_frq = Counter(preprocess_text)
    reversed = [(v, k) for k, v in word_frq.items()]
    Threshold_Word = 2
    MostFreq = int((len(reversed) * Threshold_Word / 100))
    reversed = sorted(reversed, reverse=True)[:MostFreq]

    # Process named entities
    NER = [ent.text.lower().strip() for ent in doc.ents]
    NER = Preprocess_text(' '.join(NER))
    word_frq = Counter(NER)
    reversed_ner = [(v, k) for k, v in word_frq.items()]
    Threshold_ent = 10
    MostFreq = int((len(reversed_ner) * Threshold_ent / 100))
    reversed_ner = sorted(reversed_ner, reverse=True)[:MostFreq]

    # Append most frequent words and entities to the lists
    for _, word in reversed:
        Most_frq_word.append(word)
    for _, word in reversed_ner:
        Most_frq_entity.append(word)

    # Calculate sentiment for the most common word in the article
    if reversed:
        sent = SentimentCommonTopic(reversed[0][1], list(doc.sents))
        topic_key = f"{reversed[0][1]}_{index}"
        Topic_withSent[topic_key] = {'POSITIVE': sent[0], 'NEGATIVE': sent[1]}



    index += 1



# Function to create bar plots of the most frequent words
def MostFrqWord(Most_frq_word):
    Count_ent = Counter(" ".join(Most_frq_word).split())
    Threshold_ent = int(len(Count_ent) * 5 / 100)
    reversed_ner = [(v, k) for k, v in Count_ent.items()]
    MostFreq = int((len(reversed_ner) * Threshold_ent / 100))
    reversed_ner = sorted(reversed_ner, reverse=True)[:MostFreq]

    most_similar = {k: v for v, k in reversed_ner}

    # Convert dictionary to lists for plotting
    words = list(most_similar.keys())
    frequencies = list(most_similar.values())

    # Create a bar chart using Plotly
    fig = px.bar(x=words, y=frequencies, labels={'x': 'Words', 'y': 'Frequency'},
                 title='Most Frequent Words Across Articles')
    fig.update_layout(xaxis_tickangle=-45)
    fig.show()

MostFrqWord(Most_frq_word)

# Function to create bar plots of the most frequent entities
def MostFreqEnt(Most_frq_entity):
    Count_ent = Counter(" ".join(Most_frq_entity).split())
    Threshold_ent = int(len(Count_ent) * 5 / 100)
    reversed_ner = [(v, k) for k, v in Count_ent.items()]
    MostFreq = int((len(reversed_ner) * Threshold_ent / 100))
    reversed_ner = sorted(reversed_ner, reverse=True)[:MostFreq]

    most_similar = {k: v for v, k in reversed_ner}

    # Convert dictionary to lists for plotting
    entities = list(most_similar.keys())
    frequencies = list(most_similar.values())

    # Create a bar chart using seaborn
    sb.barplot(x=entities, y=frequencies)
    plt.title('Most Frequent Entities Across Articles')
    plt.xticks(rotation=45, ha='right')
    plt.show()

MostFreqEnt(Most_frq_entity)

#  Creating and displaying word clouds for visualizing frequent words and entities.

# Visualize Top Most Frequent Words in all articles
WC = WordCloud(width=800, height=800, background_color='white', min_font_size=10).generate(' '.join(Most_frq_word))
plt.suptitle("Most Frequent Words in all articles")
plt.imshow(WC)
plt.axis('off')
plt.show()

# Visualize Top Most Frequent Entities in all articles
WC = WordCloud(width=800, height=800, background_color='white', min_font_size=10).generate(' '.join(Most_frq_entity))
plt.suptitle("Most Frequent Named Entities in all articles")
plt.imshow(WC)
plt.axis('off')
plt.show()









# Function To visualise positive and negative sentiments
def visualize_sentiments(data, top_n=10):
    # Extract words and their sentiment scores
    sentiment_scores = {word: sentiments for word, sentiments in data.items()}

    # Sort by the highest combined absolute sentiment scores
    sorted_sentiment_scores = sorted(sentiment_scores.items(), key=lambda x: max(x[1]['POSITIVE'], x[1]['NEGATIVE']),
                                     reverse=True)

    # Select top N sentiments
    top_sentiments = sorted_sentiment_scores[:top_n]

    # Separate the words, positive scores, and negative scores
    words = [item[0] for item in top_sentiments]
    positive_scores = [item[1]['POSITIVE'] for item in top_sentiments]
    negative_scores = [item[1]['NEGATIVE'] for item in top_sentiments]

    # Plotting the data
    x = np.arange(len(words))  # the label locations
    width = 0.35  # the width of the bars

    fig, ax = plt.subplots(figsize=(12, 8))

    bars1 = ax.bar(x - width / 2, positive_scores, width, label='Positive', color='blue')
    bars2 = ax.bar(x + width / 2, negative_scores, width, label='Negative', color='red')

    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_xlabel('Words')
    ax.set_ylabel('Sentiment Scores')
    ax.set_title('Positive and Negative Sentiment Scores by Words')
    ax.set_xticks(x)
    ax.set_xticklabels(words, rotation=45, ha='right')
    ax.legend()



visualize_sentiments(data = Topic_withSent,top_n=10)