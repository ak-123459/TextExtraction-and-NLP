import requests
import pandas as pd
import os
import re
import spacy

# Load the Spacy model for natural language processing
nlp_model = spacy.load('en_core_web_sm')

# Get the current directory of the Python file
current_directory = os.path.abspath(os.path.dirname(__file__))

# Define paths to various resource files and directories
StopWords = current_directory + '\\Resources\\Stopwords\\'
MasterDirectory = current_directory + '\\Resources\\MasterDictionary\\'
ArticlesFiles = current_directory + '\\Extracted_articles\\'
Easy_words = current_directory + '\\Resources\\3000_easy_words.txt'
OutPutDataStructureFile = current_directory + '\\Resources\\Output Data Structure.xlsx'


# Function to get all stop words from multiple files and combine them into one list
def List_Stop_words():
    ALL_stopWords = []
    # Iterate through all stop word files in the specified directory
    for stopword in os.listdir(StopWords):
        # Open each stop word file
        with open(StopWords + str(stopword), 'r') as file:
            # Read and add each stop word file's content to the list
            ALL_stopWords += file.read().lower().strip().split()
    return ALL_stopWords


# Function to open and read positive and negative words files
def open_pos_neg_File():
    neg_file = os.listdir(MasterDirectory)[0]
    pos_file = os.listdir(MasterDirectory)[1]

    with open(MasterDirectory + str(neg_file), 'r') as neg_f:
        neg = neg_f.read().strip().split()
    with open(MasterDirectory + str(pos_file), 'r') as pos_f:
        pos = pos_f.read().strip().split()

    return [neg, pos]


# Function to determine complex words based on syllables and presence in easy words list
def ComplexWords(tokens):
    ComplexWord = ''
    with open(Easy_words, 'r', encoding='utf-8') as file_word:
        easy_words = file_word.read().lower().strip().split()

    SyllableCount = 0
    vowels = ['a', 'e', 'i', 'o', 'u']
    tokens_char = tokens.replace("", ",").replace(",", " ").split()

    if '.' not in tokens_char:
        for char in vowels:
            if char in tokens_char:
                SyllableCount += 1
        if tokens not in easy_words and SyllableCount > 2 and len(tokens) > 7:
            ComplexWord = tokens

    return ComplexWord


# Function to calculate average sentence length
def Avg_Sent_Len(totalWords, totalsent):
    return totalWords / totalsent


# Function to calculate percentage of complex words
def Per_comp_words(total_colmplex_words, totalWords):
    return total_colmplex_words / totalWords


# Function to count syllables in a word
def count_syllables(word):
    word = word.lower()
    vowels = "aeiou"
    syllable_count = 0

    # Basic regex to find vowel groups
    syllable_groups = re.findall(r'[aeiou]+', word)
    syllable_count = len(syllable_groups)

    # Handle exceptions for 'es' or 'ed' endings
    if word.endswith("es") or word.endswith("ed"):
        if len(syllable_groups) > 1:
            syllable_count -= 1

    # Special case for single-letter 'e' words
    if word == "e":
        syllable_count = 1

    return max(1, syllable_count)  # Ensure at least 1 syllable


# Function to count syllables in a text
def count_syllables_in_text(tokenize_word):
    words = tokenize_word.split()
    syllable_counts = {word: count_syllables(word) for word in words}
    return syllable_counts


# Function to count personal pronouns in a text
def Personal_Pron_Count(tokenize_word):
    personal_pronouns = ["i", "you", "he", "she", "it", "we", "they",
                         "me", "him", "her", "us", "them",
                         "my", "your", "his", "her", "its", "our", "their",
                         "mine", "yours", "hers", "ours", "theirs"]
    return 1 if tokenize_word in personal_pronouns else 0


# Load the output data structure template
OutPutDataStr = pd.read_excel(OutPutDataStructureFile)


# Main function to analyze the text
def Variables_Computation():
    positive_score = []
    negative_score = []
    List_ = []
    Comp_words_List = []
    Personal_pronouns_list = []
    Word_len_list = []

    # Get all stop words in a single list
    ALL_stopWords = List_Stop_words()

    Index = 0
    print("Variable Computation in progress...")

    # Iterate through all articles
    for article_file in os.listdir(ArticlesFiles):
        with open(ArticlesFiles + str(article_file), 'r', encoding='utf-8') as save_articles:
            start = save_articles.read()

        # Extract the main content of the article
        indices_object = re.finditer(pattern='Article:', string=start)
        endIn = [i.end() for i in indices_object][0]
        article = start[endIn:].strip()

        model_article = nlp_model(article)

        Syllables_list = []
        List_N = []

        for token in model_article:
            Comp_word = ComplexWords(token.text.lower())
            if Comp_word != '':
                Comp_words_List.append(Comp_word)

            if token.ent_type_ not in ['GPE', 'ORG']:
                Personal_pronouns_list.append(Personal_Pron_Count(token.text.lower()))

            if not token.is_punct and token.text != '\n' and token.text != '\n\n' and token.text != '\xa0 ':
                if token.text.lower() not in ALL_stopWords:
                    Syllables_list.append(count_syllables(token.text.lower()))
                    List_N.append(token.text.lower())
                    Word_len_list.append(len(token.text))

                    if token.text.lower() in open_pos_neg_File()[0]:
                        negative_score.append(-1)
                    if token.text.lower() in open_pos_neg_File()[1]:
                        positive_score.append(1)

        # Calculate various scores and metrics
        POL_SCORE = (sum(positive_score) - sum(negative_score)) / (sum(positive_score) + sum(negative_score) + 0.000001)
        POS_SCORE = sum(positive_score)
        NEG_SCORE = sum(negative_score) * -1
        SUBJ_SCORE = (sum(positive_score) + sum(negative_score)) / (len(List_N) + 0.000001)
        AVG_SENT_LENGTH = Avg_Sent_Len(len(article.split()), len(list(model_article.sents)))
        PERCENT_COMP = Per_comp_words(len(Comp_words_List), len(article.split()))
        FOG_INDEX = 0.4 * (AVG_SENT_LENGTH + PERCENT_COMP)
        AVG_NUM_WORDS_SENT = len(article.split()) / len(list(model_article.sents))
        COMP_WORD_COUNT = len(Comp_words_List)
        CLEAN_WORD_COUNT = len(List_N)
        AVERAGE_SYLLABEL = sum(Syllables_list) / len(List_N)
        PERSON_PRONOUNS = sum(Personal_pronouns_list)
        AVG_WORD_LEN = sum(Word_len_list) / len(List_N)

        # Columns and values for the output DataFrame
        COLUMNS = ['POSITIVE SCORE', 'NEGATIVE SCORE', 'POLARITY SCORE',
                   'SUBJECTIVITY SCORE', 'AVG SENTENCE LENGTH',
                   'PERCENTAGE OF COMPLEX WORDS', 'FOG INDEX',
                   'AVG NUMBER OF WORDS PER SENTENCE', 'COMPLEX WORD COUNT', 'WORD COUNT',
                   'SYLLABLE PER WORD', 'PERSONAL PRONOUNS', 'AVG WORD LENGTH']

        VALUES = [POS_SCORE, NEG_SCORE, POL_SCORE, SUBJ_SCORE,
                  AVG_SENT_LENGTH, PERCENT_COMP, FOG_INDEX, AVG_NUM_WORDS_SENT,
                  COMP_WORD_COUNT, CLEAN_WORD_COUNT, AVERAGE_SYLLABEL, PERSON_PRONOUNS, AVG_WORD_LEN]

        OutPutDataStr.loc[Index, COLUMNS] = VALUES

        # Reset variables for the next article
        positive_score = []
        negative_score = []
        Comp_words_List = []
        Personal_pronouns_list = []
        Syllables_list = []
        Word_len_list = []
        List_.append(List_N)


        Index += 1


    print("OutPutData --->>>\n",OutPutDataStr.head(5))
    print()
    print()

    # Make a directory to save Output Data Structure
    output_directory = current_directory + '\\OUTPUT DATA STRUCTURE'
    if not os.path.exists(output_directory):
        os.mkdir(output_directory)

    output_path = output_directory + '\\Output Data Structure.xlsx'

    OutPutDataStr.to_excel(output_path)

    print(f"-->>>>>>>  Output Data Structure file Saved Successfully in {output_path}")


Variables_Computation()

print()
print("Variable Computation is Completed...")
