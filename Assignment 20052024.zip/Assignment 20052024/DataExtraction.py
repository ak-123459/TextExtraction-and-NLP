# Import necessary libraries
import os  # For operating system dependent functionality
import time  # To handle time-related tasks
import requests  # To send HTTP requests
from bs4 import BeautifulSoup  # To parse HTML and XML documents
import pandas as pd  # For data manipulation and analysis
import openpyxl  # To read/write Excel 2010 xlsx/xlsm/xltx/xltm files



print()
print()


# Get the directory where the current file is located
current_directory = os.path.abspath(os.path.dirname(__file__))

# Define the path where articles will be saved
article_path = os.path.join(current_directory, "Extracted_articles")

# Function to save the article in a specified location
def article_save(URL_ID, title_, article_):
    """
    Saves the article content to a text file.

    Parameters:
    URL_ID (str): The ID of the URL.
    title_ (str): The title of the article.
    article_ (str): The content of the article.
    """
    if(os.path.exists(article_path)):
        # Save the article with URL_ID as the filename
        with open(os.path.join(article_path, f"{URL_ID}.txt"), 'w', encoding='utf-8') as f:
            f.write(f"Title: {title_}\n\nArticle: {article_}")

    else:

      os.makedirs(article_path)



# Variable to hold the input path
path_input_data = current_directory+"\\"+'Resources\\Input.xlsx'



# Read the input.xlsx file using pandas
input_data = pd.read_excel(path_input_data)


# Variables to store the title and article content
title_ = ''
article_ = ''

# Variable to track the current URL number
url_no = 0



# Check if articles exists or not
if(len(os.listdir(article_path))!=len(input_data['URL'])):

    # Loop through all URLs in the input file (processing only the first 20 for this example)
    for url in input_data['URL']:
        # Send a request to the URL and get the webpage content
        web_page = requests.get(url)
        page_content = BeautifulSoup(web_page.content, 'html.parser')

        # Extract the title of the article
        try:
            title_ = page_content.find('h1').text
        except AttributeError:
            title_ = "No Title Found"

        # Extract the article content
        article_cont = page_content.find_all('div', class_="td-post-content tagdiv-type")
        article_ = article_cont[0].text if article_cont else "No Article Content Found"

        # Truncate the article content if it contains 'Blackcoffer Insights'
        try:
            limit_index = article_.index('Blackcoffer Insights')
            article_ = article_[:limit_index]
        except ValueError:
            pass

        # Save the article using the article_save function
        article_save(input_data['URL_ID'].iloc[url_no], title_, article_)

        # Print completion message if all URLs are processed
        if url_no + 1 == len(input_data['URL']):
            print("Articles Extracted Successfully...\n")
            print(f"    Extracted articles saved in  {article_path}")


        # Increment the URL number
        url_no += 1


else:

        print(f"Extracted articles saved in  {article_path}")

