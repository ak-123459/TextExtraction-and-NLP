# Title
Data Extraction and NLP
 
## **Objective** :- 
The objective of this assignment is to extract textual data articles from the given URL and perform text analysis and compute variables.

## Overview :- 
In this project we are going to extract text data from given url.In my case the url we will get from file  ***D:\Assignment 20052024\Resources\\Input.xlsx*** please specify your directory path that contain **MasterDictionary Folder,Stopwords Folder,input.xlsx,outputDataStructure.xlsx.**
we will extract data(title and article text only) from website and save it.in the next step we will analyse article text data using techniques nlp.
we will use text analysis method word frequency,named entity and sentiment analysis.we will visualize textual data to understand trends and pattern.
and at the end we will compute the variables and save in name ***OUTPUT DATA STRUCTURE.xlsx(excel format)***.

## Approach to the Solution:-

1.Data Collection:-

```text
This is Very First step to collect data that we will need to process.Here I have directory  **D:\Assignment 20052024\Resources\\** that contains files 
MasterDictionary Folder,Stopwords Folder,
input.xlsx,outputDataStructure.xlsx.we will use these files for text extraction,text analysis,and variable computation.

```
**Directory That contain assignment related data files**

![alt-text](C:\\Users\mishr\OneDrive\Pictures\Screenshots\Screenshot%202024-05-19%20010049.png "Assignment_data_path")

**assignmet files in that directory**

![alt-text](C:\Users\mishr\OneDrive\Pictures\Screenshots\Screenshot%202024-05-19%20012237.png "Assignment_data_path")



#
2.Data Extraction:-

```text 
Now we have url data in D:\Assignment 20052024\Resources\output.xlsx file we will load dataset  in python file using pandas library.
Now we will use webscraping tools like BeautifulSoup,requests,to scrape articles data.we need to extract only title and text so we will find the tag name and class that conatin title and text in this case
for text(tag = 'div' , class="td-post-content) ,title(tag = "h1")there are total 100 artcles so this will taking sometimes to scrape 
the aricles.extracted articles will save in . format in directory D:\\Extracted_articles\\ with extension .txt format.
```

**Title Extraction of h1 tag**

![alt-text](C:\Users\mishr\OneDrive\Pictures\Screenshots\Screenshot%202024-05-19%20011307.png "Assignment_data_path")


**Text Extraction of div tag and class td-ss-main-content**

![alt-text](C:\Users\mishr\OneDrive\Pictures\Screenshots\Screenshot%202024-05-19%20011342.png "Assignment_data_path")

**Extracted Articles Will be save in D:\ drive ExtractedArticles Directory**



#

3.Data Analysis:-

```text
we have collected articles(title and text).Now we are going to perform analysis.first we will load all articles.here I will use spacy,matplotlib,plotly and other library.firstly we will clean the text using spacy  by removing stop words,puntcuation marks,white spaces.we will loop all aricles one by one and compute the frequency,sentments and enities.
after computing we will use visualization tools like wordcloud,matplotlib,seaborn,plotly.
we will understand relationship between articles by most frequent words,entities,presentation of an entity across the articles.
.
```
**Visualise the Most frequents words from all the articles**


**Visualise the Most frequents entities from all the articles**


**Visualise the Word that occur accross the articles**


**Visualise the Entities that occur accross the articles**


**Top 10 Most Frequent word with positive and negative sentiment in senetence**




4.Variable Computation:- 


```text

we will compute all variable that specify in TextAnalysis.docx file.We will load all dataset that contain title and text (articles) for computation.we will use spacy that is a populer nlp library for python.
we will also use here our directory "D:\20211030 Test Assignment" that contain stopwords,MatserDirectory.we will also use stopwords directory that contain .txt files for removing stopwords from text.using spacy we will also  tokenized the text,clean the text(punctuation marks),computing the variable personal pronounsations.after computation of each variables we will save the computed varaibles in D:\OUTPUT DATA STRUCTURE.xlsx file.

```

## Windows 

## Running the Script

this very crucial step to run the python script for output and find the objective that we need.there are many ways to run python script we will discuss about running python script in Command Line,pycharm(IDE).

Using Command Line:- 

1. **Ensure Python is Installed:**
Check python install or not in your system using command 👉 python -V
in my case  C:\Users\mishr>python -V
this command will show the version of python if installed in your system.if python not installed follow the link download and install it. 
link -> https://www.python.org/downloads/




2. **Install Dependencies:**
   - Install the required dependencies by running:
   

   ``` python -m pip install -r requirements.txt```



For Command line use:- python -m pip install .....


[Note]: # Replace the requirements.txt file with exact path of requirements.txt


3. **Run the script**

Run python script using command:-

```python "main.py"```

[//]: # Replace main.py by original file name that you want to run
 
In my Case :-

PS C:\Users\mishr> python "main.py".py


 **Run Python Scripts using an IDE/Text Editor**
```text
To run Python script on an IDE (Integrated Development Environment) like PyCharm or vs code, you will have to do the following:

you have to go to the file location and right click on file and open with text editor or IDE that you have install.now file will open.in existing project you have to check that all dependenies install in your project.
Now click on run button on ide/text editor.

```
## Dependencies

List of all the dependencies required for the project  For example:
```text
wordcloud==1.9.3
spacy==3.7.4
seaborn==0.13.2
requests==2.31.0
plotly==5.22.0
numpy==1.26.64
matplotlib==3.8.4
en-core-web-sm==3.7.1
beautifulsoup4==4.12.3
openpyxl==3.1.2
pandas==2.2.1
regex==2024.5.15
textblob==0.18.0post0
```