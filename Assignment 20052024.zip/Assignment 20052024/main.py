# Import necessary libraries
import os  # For operating system dependent functionality
import time  # To handle time-related tasks
import re  # For regular expression operations
from collections import Counter  # To count hashable objects

# Data manipulation and analysis
import pandas as pd  # For data manipulation and analysis
import numpy as np  # For numerical operations

# Web scraping
import requests  # To send HTTP requests
from bs4 import BeautifulSoup  # To parse HTML and XML documents

# Data visualization
import matplotlib.pyplot as plt  # For plotting data
import seaborn as sb  # For data visualization based on matplotlib
import plotly.express as px  # For interactive plots

# Natural Language Processing (NLP)
import spacy  # For NLP tasks
from wordcloud import WordCloud  # To generate word clouds
from textblob import TextBlob  # For text processing and NLP

# For working with Excel files
import openpyxl  # To read/write Excel 2010 xlsx/xlsm/xltx/xltm files

import subprocess

# Define the path to your scripts
current_directory = os.path.abspath(os.path.dirname(__file__))
script1_path = os.path.join(current_directory, 'DataExtraction.py')
script2_path = os.path.join(current_directory, 'DataAnalysis.py')
script3_path = os.path.join(current_directory, 'VariableComputation.py')


# Function to run a script
def run_script(script_path):
    try:
        result = subprocess.run(['python', script_path], capture_output=True, text=True)
        print(f"Output of {script_path}:\n{result.stdout}")
        if result.stderr:
            print(f"Error in {script_path}:\n{result.stderr}")
    except Exception as e:
        print(f"Failed to run {script_path}: {e}")



# Print a header to indicate the start of the data extraction process

print()

print()
# Run scripts
print("<<<<<<<<<----------               Data Extraction         -------------->>>>>>\n\n")



print("    >>>>                Make Sure You have an active internet conection..\n\n            ")

print("    >>>>>               Article Extraction in progress...         \n")


print()

print()

print(f" >>>>>    Extracted articles will be save in  {current_directory}\\Extracted_articles\n\n")
run_script(script1_path)


print("   >>>>>   Data Extraction Completed...\n\n")



# Print a header to indicate the start of the Variables Computation  process


print("<<<<<<<<<------                Variables Computation       -------------->>>>>>")
print()

print()

print("    >>>>   Wait for Variables Computation....\n\n")
print(f">>> Computed Variables Will be save in location {current_directory}\\\\OUTPUT DATA STRUCTURE\n\n")
run_script(script3_path)

print("   >>>>>   Variables Computation Completed...\n\n")

# Print a header to indicate the start of the data analysis process


print("<<<<<<<<<-----------            Data Analysis ------------------->>>>>>")
print()

print()

print("  >>>       Wait for Visualisation....\n")

print("  >>>>     It's Will Take Some time..\n\n")

print()


run_script(script2_path)

print("  >>>>     Data Visualisation Successfully...")
